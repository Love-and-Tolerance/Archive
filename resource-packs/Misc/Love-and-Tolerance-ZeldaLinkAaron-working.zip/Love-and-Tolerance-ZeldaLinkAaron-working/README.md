# Love & Tolerance

<img src="https://i.imgur.com/s2mO3w5.png" alt="L&T"></img>

![Downloads](https://img.shields.io/github/downloads/MineLittlePony/Love-and-Tolerance/total.svg?color=yellowgreen)
[![Discord Server](https://img.shields.io/discord/182490536119107584.svg?color=blueviolet)](https://discord.gg/HbJSFyu)

This is a Minecraft resource pack inspired by the visual art style and design of the show _My Little Pony: Friendship is Magic_. Bright colours and (moderate) pony references abound!


This resource pack is:

 - Brightly coloured, rainbow hued
 - Filled with pony pictures as paintings
 - Probably he best way to explore Equestria.
 - Compatible with Optifine and CTM textures
 - Used on the famous "Brohoof" minecraft servers

## Credits

### Created by
 - Arekuzu
 - Hazzat
 - Hawk

### Maintained by

 - Bronydogz (1.10)
 - SolisLink/ZeldaLinkAaron (1.11-1.12)
 - Vivian (1.14+)
